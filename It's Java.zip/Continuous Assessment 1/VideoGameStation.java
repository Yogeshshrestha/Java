
public class VideoGameStation
{
    private String gameStation;
    private String videoGame;
    private String customerName;
    private String customerType;
    private String bookingDate;
    private int duration;
    private int hourlyRate;
    private boolean availableStatus;

    public VideoGameStation(String gameStation, String videoGame, int hourlyRate){
        this.gameStation = gameStation;
        this.videoGame = videoGame;
        this.hourlyRate = hourlyRate;
        this.customerName = "";
        this.customerType = "";
        this.bookingDate = "";
        this.duration = 0;
        this.availableStatus = true;
    }

    //getters
    public String getGameStation(){
        return gameStation;
    }

    public String getVideoGame(){
        return videoGame;
    }

    public String getCustomerName(){
        return customerName;
    }

    public String getCustomerType(){
        return customerType;
    }

    public String getBooking(){
        return bookingDate;
    }

    public int getDuration(){
        return duration;
    }

    public int getRate(){
        return hourlyRate;
    }

    public boolean getStatus(){
        return availableStatus;
    }

    public void setCustomType(String customerType){
        this.customerType = customerType;
    }

    public void setHour(int hour){
        this.hourlyRate = hour;
    }


    public void Book(String customerName, String customerType, String bookingDate, int duration){
        if(this.availableStatus == false){
            System.out.println("Video game isnot available");
        }
        else{
        this.customerName = customerName;
        this.customerType = customerType;
        this.bookingDate = bookingDate;
        this.duration = duration;
        this.availableStatus = false;
        System.out.println("Dear " + customerName + " your booking has been recorded.");
    }
    } // to book the gamestation

    public void IsAvailable(){
        if(this.availableStatus == true)
        {
            System.out.println("The gamestation is open,dear customers you can book it.");
        }
        else{
            this.customerName = "";
            this.customerType = "";
            this.bookingDate = "";
            this.duration = 0;
            this.availableStatus = true;
        }
    } // to make the gamestation is available

    public void Display(){
        System.out.println("Game station: " + getGameStation());
        System.out.println("Hourly Rate: " + getRate());
    } // to display all the available gamestation and prices
    
    public static void main(String[] args){
        VideoGameStation game = new VideoGameStation("GameStation","God of war 3", 100);
        game.Book("Anubis","Group","27th january,2020",1);
        game.Book("Hari","Premier","27/1/2020",2);
        game.Display();
    } // to test the methods
}