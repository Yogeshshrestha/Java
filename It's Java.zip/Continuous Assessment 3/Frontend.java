import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;


public class Frontend extends JFrame{
    JMenuBar menuBar;
    Frontend self = this;
    JCheckBox status;
    JTextField firstName,secondName,phoneNum;
    JRadioButton foreName,surName;
    JButton subClear,subSearch,subAdd,subRemove;
    DefaultTableModel model;
    JTable table;
    ButtonGroup bGroup;

    public Frontend(){
        setVisible(true);
        setTitle("Phone Book");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(400,400));
        setJMenuBar(getMenu());
        bGroup = new ButtonGroup();
        status = new JCheckBox("Private");
        firstName = new JTextField(20);
        secondName = new JTextField(20);
        phoneNum = new JTextField(20);
        foreName = new JRadioButton("Forename,Surname");
        surName = new JRadioButton("Surname,Forename");
        subClear = new JButton("Clear");
        subClear.setPreferredSize(new Dimension(80,100));
        subSearch = new JButton("Search");
        subSearch.setPreferredSize(new Dimension(80,100));
        subAdd = new JButton("Add");
        subAdd.setPreferredSize(new Dimension(80,100));
        subRemove = new JButton("Remove");
        subRemove.setPreferredSize(new Dimension(80,100));
        model = new DefaultTableModel();
        table = new JTable(model);
        add(getApp());
        addData();
        clearData();
        removeData();
        search();
        pack();
        setLocationRelativeTo(null);
    } //constructor Frontend

    private JMenuBar getMenu(){
        menuBar = new JMenuBar();
        JMenu subFile = new JMenu("File");
        JMenu subEdit = new JMenu("Edit");
        JMenu subHelp = new JMenu("Help");

        JMenuItem subExit = new JMenuItem("Exit");
        subExit.setMnemonic(KeyEvent.VK_E); //shortcut key for exit alt+E
        JMenuItem clear = new JMenuItem("Clear");
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subClear.doClick();
            } // action listener for clear subJMenuItem
        });
        clear.setMnemonic(KeyEvent.VK_C);//shortcut key for clear alt+C
        JMenuItem search = new JMenuItem("Search");
        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subSearch.doClick();
            }// action listener for search subJMenuItem
        });
        search.setMnemonic(KeyEvent.VK_S);
        JMenuItem add = new JMenuItem("Add");//shortcut key for search alt+S
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subAdd.doClick();
            }
            // action listener for add subJMenuItem
        });
        add.setMnemonic(KeyEvent.VK_A);//shortcut key for add alt+A
        JMenuItem remove = new JMenuItem("Remove");
        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subRemove.doClick();
            }// action listener for remove subJMenuItem
        });
        remove.setMnemonic(KeyEvent.VK_R);//shortcut remove for exit alt+R
        JMenuItem about = new JMenuItem("About");
        about.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               JOptionPane.showMessageDialog(self,"It is still in trial version.","About",JOptionPane.ERROR_MESSAGE);
                // action listener for about subJMenuItem
            }
        });
        about.setMnemonic(KeyEvent.VK_A);//shortcut about for exit alt+A

        subExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
            // action listener for exit subJMenuItem
        });
        subFile.add(subExit);

        subEdit.add(clear);
        subEdit.add(search);
        subEdit.addSeparator();
        subEdit.add(add);
        subEdit.add(remove);
        subHelp.add(about);

        menuBar.add(subFile);
        menuBar.add(subEdit);
        menuBar.add(subHelp);
        return menuBar;
    } //menu panel

    private JPanel getInfo(){
        JPanel infoPanel = new JPanel();
        infoPanel.setBorder(BorderFactory.createTitledBorder("Info:"));
        infoPanel.setLayout(new GridLayout(4,2));

        infoPanel.add(new JLabel("First Name"));
        infoPanel.add(firstName);
        firstName.setToolTipText("Enter your first name");
        infoPanel.add(new JLabel("Second Name"));
        infoPanel.add(secondName);
        secondName.setToolTipText("Enter your last name");
        infoPanel.add(new JLabel("Phone"));
        infoPanel.add(phoneNum);
        phoneNum.setToolTipText("Enter your phone number");
        infoPanel.add(status);

        return infoPanel;
    } //info panel

    private JPanel getBox(){
        JPanel panelBox = new JPanel();
        panelBox.setLayout(new GridLayout(2,2));

        panelBox.add(subClear);
        panelBox.add(subSearch);
        panelBox.add(subAdd);
        panelBox.add(subRemove);
        return panelBox;
    } //buttons panel(add,remove,search,add)

    private JPanel getFile(){
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("File as:"));
        panel.setLayout(new GridLayout(2,1,5,40));
        bGroup.add(foreName);
        bGroup.add(surName);

        panel.add(foreName);
        //for changing columns on changing radio button
        foreName.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                table.moveColumn(1,0);
            }
        });
        panel.add(surName);

        //for changing columns on changing radio button
        surName.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                table.moveColumn(1,0);
            }
        });

        return panel;
    } // file panel

    private JPanel dataPanel(){
        String [] columnNames = {"First Name","Last Name","Phone Number","Status"};
        model.setColumnIdentifiers(columnNames);
        table.setSelectionBackground(Color.GRAY);

        JPanel dataPanel = new JPanel();
        dataPanel.setBorder(BorderFactory.createTitledBorder("File:"));
        JScrollPane scrollable = new JScrollPane(table);
        dataPanel.add(scrollable);
        table.setTableHeader(null);
        return dataPanel;
    } // table panel

    private JPanel getApp(){
        JPanel layout = new JPanel();
        layout.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5,5,5,5);

        gbc.gridx = 1;
        gbc.gridy = 0;
        layout.add(getInfo(),gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        layout.add(getFile(),gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridheight = 6;
        layout.add(getBox(),gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 8;
        layout.add(dataPanel(),gbc);

        return layout;
    } // layout design using gridbag layout

    private void addData(){
        subAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    String userName = firstName.getText().trim();
                    String lastName = secondName.getText().trim();
                    long phone = Long.parseLong(phoneNum.getText());
                    if (userName.isEmpty()) {
                        JOptionPane.showMessageDialog(self, "Enter your first name");
                    }
                    else if (lastName.isEmpty()) {
                        JOptionPane.showMessageDialog(self, "Enter your last name");
                    }
                     else if (userName.isEmpty() || lastName.isEmpty()) {
                         JOptionPane.showMessageDialog(self, "You must enter information", "Names", JOptionPane.ERROR_MESSAGE);
                     }
                     else {
                        String userStatus;
                        if (status.isSelected()) {
                            userStatus = status.getText().toString();
                        } else {
                            userStatus = "";
                        }
                        Object[] data = {userName, lastName, phone, userStatus};
                        model.addRow(data);
                    }
                 }
                catch (NumberFormatException Ex) {
                    JOptionPane.showMessageDialog(self,"Enter the number in Phone text area","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    } // add data to table

    private void clearData(){
         subClear.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 firstName.setText("");
                 secondName.setText("");
                 phoneNum.setText("");
                 status.setSelected(false);
                 table.clearSelection();
                 bGroup.clearSelection();
             }
         });
    } //clear data from table

    private void removeData(){
        subRemove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                try {
                    int choice = JOptionPane.showOptionDialog(self,"Are you sure you want to delete this record?","Delete",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,null,null);
                    if(choice ==JOptionPane.YES_OPTION) {
                        model.removeRow(selectedRow);
                    }
                    else{
                        System.exit(1);
                    }
                }
                catch (ArrayIndexOutOfBoundsException ex){
                    JOptionPane.showMessageDialog(self,"Choose a row or there is no more row present in the table","Cannot delete Data",JOptionPane.QUESTION_MESSAGE);
                }
            }
        });
    } //to remove data from table

    private void search(){
        subSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(self,"Search functionality will be supported in the professional version","Search",JOptionPane.QUESTION_MESSAGE);
            }
        });
    } // to search data from table


    public static void main(String[] args){
        new Frontend();
    }
}
