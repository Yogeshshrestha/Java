import java.util.ArrayList;
import java.util.Collections;
import java.lang.IndexOutOfBoundsException;

public class GameParlour
{
    //Q.N.8 (ArrayList of VideoGameStation objects)
    private ArrayList <VideoGameStation> gameList = new ArrayList<VideoGameStation>();

    //Q.N.9 (Creating new VideoGameStation object)
    public void addStation(String gameStation, String videoGame, int hourlyRate){
        this.gameList.add(new VideoGameStation(gameStation,videoGame,hourlyRate));
    }

    //Q.N.10 (To Remove VideoGameStation object based on index)
    public void removeStation(int index){
        try{
            this.gameList.remove(index);
        }
        catch(IndexOutOfBoundsException ex){
            System.out.println("Game does not exist");
        }
    }

    //Q.N.11 (To Book game based on index of Arraylist)
    public void bookStation(int index,String customerName, String customerType, String bookingDate, int duration){
        try{
            VideoGameStation v = this.gameList.get(index);
            v.book(customerName,customerType,bookingDate,duration);
        }
        catch(IndexOutOfBoundsException ex){
            System.out.println("The game isnot available");
        }
    }

    //Q.N.12 (To free game)
    public void gameFree(int index){
        try{
            VideoGameStation v = this.gameList.get(index);
            v.isAvailable();
        }
        catch(IndexOutOfBoundsException ex){
            System.out.println("Game with this index doesnot exist");
        }
    }

    //Q.N.13 (to display game stations which are free)
    public void gameDisplay(){
        for(VideoGameStation z: gameList){
            if(z.getStatus()){
                System.out.println("Gamestation detail No:" + gameList.indexOf(z));
                z.display();
            }
        }
    }

    //Q.N.14 (to search game station)
    public void search(String gameName,int hourlyRate){
        for(VideoGameStation z: gameList){
            if(z.getStatus()){
                if(z.getGameStation().equalsIgnoreCase(gameName) && z.getRate()<= hourlyRate)
                {
                    System.out.println("Game Station detail No:" + gameList.indexOf(z));
                    z.display();
                }
            }
            else{
                System.out.println("Game Station doesnot exist");
            }
        }
    }

    //Q.N.15 (to display gamestation and customers name in ascending order)
    public void displayAscending(){
        Collections.sort(gameList);

        for(VideoGameStation z: gameList){
            if(!z.getStatus()){
                System.out.println("Video Game Station Name:" + z.getGameStation());
                System.out.println("Customer Name:" + z.getCustomerName());
            }
        }
    }

    public static void main(String[] args){
        GameParlour g = new GameParlour();


        g.addStation("London Station","God of War",3);//Q.N 9
        g.addStation("Metro Station","Khal of Drom",4);//Q.N 9
        g.addStation("Game Station","God of war 2",5);//Q.N 9
        g.addStation("Game Station","NBA 2k18",7);//Q.N 9
        g.removeStation(0);//Q.N 10
        g.bookStation(1,"Hari","Premium","25th january",5);//Q.N 11
        g.bookStation(0,"Anubis","Premium","25th january",5);//Q.N 11
        g.gameFree(2);//Q.N 12
        g.gameDisplay();//Q.N 13
        g.search("London Station",4);//Q.N 14
        g.displayAscending();//Q.N 15
    }
}
