import org.omg.Messaging.SYNC_WITH_TRANSPORT;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Frontend extends JFrame{
    JMenuBar menuBar;
    Frontend self = this;
    JCheckBox status;
    JTextField firstName,secondName,phoneNum;
    JRadioButton foreName,surName;
    JButton subClear,subSearch,subAdd,subRemove;
    DefaultTableModel model;
    JTable table;
    ButtonGroup bGroup;
    UserRegistration reg;

    public Frontend(){
        setVisible(true);
        setTitle("Phone Book");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(400,400));
        setJMenuBar(getMenu());
        bGroup = new ButtonGroup();
        reg = new UserRegistration();
        status = new JCheckBox("Private");
        firstName = new JTextField(20);
        secondName = new JTextField(20);
        phoneNum = new JTextField(20);
        foreName = new JRadioButton("Forename,Surname");
        surName = new JRadioButton("Surname,Forename");
        subClear = new JButton("Clear");
        subClear.setPreferredSize(new Dimension(80,100));
        subSearch = new JButton("Update");
        subSearch.setPreferredSize(new Dimension(80,100));
        subAdd = new JButton("Add");
        subAdd.setPreferredSize(new Dimension(80,100));
        subRemove = new JButton("Remove");
        subRemove.setPreferredSize(new Dimension(80,100));
        model = new DefaultTableModel();
        table = new JTable(model);
        add(getApp());
        refreshTable();
        addData();
        clearData();
        removeData();
        updateTable();
        pack();
        setLocationRelativeTo(null);
    } //constructor Frontend

    private JMenuBar getMenu(){
        menuBar = new JMenuBar();
        JMenu subFile = new JMenu("File");
        JMenu subEdit = new JMenu("Edit");
        JMenu subHelp = new JMenu("Help");

        JMenuItem subExit = new JMenuItem("Exit");
        subExit.setMnemonic(KeyEvent.VK_E); //shortcut key for exit alt+E
        JMenuItem clear = new JMenuItem("Clear");
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subClear.doClick();
            } // action listener for clear subJMenuItem
        });
        clear.setMnemonic(KeyEvent.VK_C);//shortcut key for clear alt+C
        JMenuItem search = new JMenuItem("Search");
        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subSearch.doClick();
            }// action listener for search subJMenuItem
        });
        search.setMnemonic(KeyEvent.VK_S);
        JMenuItem add = new JMenuItem("Add");//shortcut key for search alt+S
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subAdd.doClick();
            }
            // action listener for add subJMenuItem
        });
        add.setMnemonic(KeyEvent.VK_A);//shortcut key for add alt+A
        JMenuItem remove = new JMenuItem("Remove");
        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subRemove.doClick();
            }// action listener for remove subJMenuItem
        });
        remove.setMnemonic(KeyEvent.VK_R);//shortcut remove for exit alt+R
        JMenuItem about = new JMenuItem("About");
        about.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               JOptionPane.showMessageDialog(self,"It is still in trial version.","About",JOptionPane.ERROR_MESSAGE);
                // action listener for about subJMenuItem
            }
        });
        about.setMnemonic(KeyEvent.VK_A);//shortcut about for exit alt+A

        subExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
            // action listener for exit subJMenuItem
        });
        subFile.add(subExit);

        subEdit.add(clear);
        subEdit.add(search);
        subEdit.addSeparator();
        subEdit.add(add);
        subEdit.add(remove);
        subHelp.add(about);

        menuBar.add(subFile);
        menuBar.add(subEdit);
        menuBar.add(subHelp);
        return menuBar;
    } //menu panel

    private JPanel getInfo(){
        JPanel infoPanel = new JPanel();
        infoPanel.setBorder(BorderFactory.createTitledBorder("Info:"));
        infoPanel.setLayout(new GridLayout(4,2));

        infoPanel.add(new JLabel("First Name"));
        infoPanel.add(firstName);
        firstName.setToolTipText("Enter your first name");
        infoPanel.add(new JLabel("Second Name"));
        infoPanel.add(secondName);
        secondName.setToolTipText("Enter your last name");
        infoPanel.add(new JLabel("Phone"));
        infoPanel.add(phoneNum);
        phoneNum.setToolTipText("Enter your phone number");
        infoPanel.add(status);

        return infoPanel;
    } //info panel

    private JPanel getBox(){
        JPanel panelBox = new JPanel();
        panelBox.setLayout(new GridLayout(2,2));

        panelBox.add(subClear);
        panelBox.add(subSearch);
        panelBox.add(subAdd);
        panelBox.add(subRemove);
        return panelBox;
    } //buttons panel(add,remove,search,add)

    private JPanel getFile(){
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("File as:"));
        panel.setLayout(new GridLayout(2,1,5,40));
        bGroup.add(foreName);
        bGroup.add(surName);

        panel.add(foreName);
        //for changing columns on changing radio button
        foreName.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                table.moveColumn(1,0);
            }
        });
        panel.add(surName);

        //for changing columns on changing radio button
        surName.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                table.moveColumn(1,0);
            }
        });

        return panel;
    } // file panel

    private JPanel dataPanel(){
        String [] columnNames = {"First Name","Last Name","Phone Number","Status"};
        model.setColumnIdentifiers(columnNames);
        table.setSelectionBackground(Color.GRAY);

        JPanel dataPanel = new JPanel();
        dataPanel.setBorder(BorderFactory.createTitledBorder("File:"));
        JScrollPane scrollable = new JScrollPane(table);
        dataPanel.add(scrollable);
        table.setTableHeader(null);
        return dataPanel;
    } // table panel

    private JPanel getApp(){
        JPanel layout = new JPanel();
        layout.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5,5,5,5);

        gbc.gridx = 1;
        gbc.gridy = 0;
        layout.add(getInfo(),gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        layout.add(getFile(),gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridheight = 6;
        layout.add(getBox(),gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 8;
        layout.add(dataPanel(),gbc);

        return layout;
    } // layout design using gridbag layout

    private void addData(){
        subAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    String userName = firstName.getText().trim(); //gets the string from respective JTextField
                    String lastName = secondName.getText().trim(); //gets the string from respective JTextField
                    long phone = Long.parseLong(phoneNum.getText()); //gets the string from respective JTextField and is converted to long
                    if (userName.isEmpty()) {
                        JOptionPane.showMessageDialog(self, "Enter your first name");
                    }
                    else if (lastName.isEmpty()) {
                        JOptionPane.showMessageDialog(self, "Enter your last name");
                    }
                     else if (userName.isEmpty() || lastName.isEmpty()) {
                         JOptionPane.showMessageDialog(self, "You must enter information", "Names", JOptionPane.ERROR_MESSAGE);
                     }
                     else {
                        String userStatus;
                        if (status.isSelected()) {
                            userStatus = status.getText().toString();
                        } else {
                            userStatus = "";
                        }
                        String phoneNum = Long.toString(phone);
                        reg.insert(userName, lastName, phoneNum, userStatus); //for insert query using sql server
                        refreshTable(); //to refresh JTable
                    }
                 }
                catch (NumberFormatException Ex) {
                    JOptionPane.showMessageDialog(self,"Enter the number in Phone text area","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    } // add data to JTable

    private void clearData(){
         subClear.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 firstName.setText(""); //sets text to empty string in respective JTextField
                 secondName.setText(""); //sets text to empty string in respective JTextField
                 phoneNum.setText(""); //sets text to empty string in respective JTextField
                 status.setSelected(false); //sets JRadiobutton is not selected if it was selected before
                 table.clearSelection(); //clears selection from the JTable
                 bGroup.clearSelection(); //clears selection from buttons like remove,update,clear,add
             }
         });
    } //clear data from JTable

    private void removeData(){
        subRemove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow(); //gets selected row
                try {
                    int choice = JOptionPane.showOptionDialog(self,"Are you sure you want to delete this record?","Delete",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,null,null);
                    if(choice ==JOptionPane.YES_OPTION) {
                        String phone = model.getValueAt(selectedRow,2).toString();
                        System.out.println(phone);
                        reg.delete(phone); // delete query for sql server using phoneNumber
                        refreshTable();
                    }
                    //deletes record from table if index is not out of bound
                }
                catch (ArrayIndexOutOfBoundsException ex){
                    JOptionPane.showMessageDialog(self,"Choose a row or there is no more row present in the table","Cannot delete Data",JOptionPane.QUESTION_MESSAGE);
                }
            }
        });
    } //to remove data from JTable

    private void search(){
        subSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(self,"Search functionality will be supported in the professional version","Search",JOptionPane.QUESTION_MESSAGE);
            }
        });
    } // to search data from JTable

    private void refreshTable(){
        model.setRowCount(0);
            try {
                ResultSet resultSet = reg.get();
                while(resultSet.next()){
                    model.addRow(new Object[]{
                        resultSet.getString("first_name"),
                        resultSet.getString("last_name"),
                        resultSet.getString("phone"),
                        resultSet.getString("status"),
                    });
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

    } // refreshes JTable after any query is executed in sql server

    private void updateTable(){
        table.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow(); //gets selectedRow from table
                firstName.setText(model.getValueAt(selectedRow,0).toString()); //sets firstName in JTextField
                secondName.setText(model.getValueAt(selectedRow,1).toString()); //sets secondName in JTextField
                phoneNum.setText(model.getValueAt(selectedRow,2).toString()); //sets phoneNum in JTextField
                String selectedIcon = model.getValueAt(selectedRow,3).toString(); //sets selectedIcon in JTextField
                if(selectedIcon.isEmpty()){
                    status.setSelected(false);
                }
                else{
                    status.setSelected(true);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        subSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                String id = model.getValueAt(selectedRow,2).toString();
                try{
                    String userName = firstName.getText().trim(); //getting username from table
                    String lastName = secondName.getText().trim(); //getting lastName from table
                    long phone = Long.parseLong(phoneNum.getText()); //getting phoneNumber from table
                    if (userName.isEmpty()) {
                        JOptionPane.showMessageDialog(self, "Enter your first name"); //if userName is empty
                    }
                    else if (lastName.isEmpty()) {
                        JOptionPane.showMessageDialog(self, "Enter your last name"); //if lastName is empty
                    }
                    else if (userName.isEmpty() || lastName.isEmpty()) {
                        JOptionPane.showMessageDialog(self, "You must enter information", "Names", JOptionPane.ERROR_MESSAGE); //if userName and lastName is empty
                    }
                    else {
                        String userStatus;
                        //to get the private status from table
                        if (status.isSelected()) {
                            userStatus = status.getText().toString(); // if JRadioButton is selected then private is taken as string for sql server
                        }
                        else {
                            userStatus = ""; //if JRadioButton is not selected than instead of private we get empty string in sql server
                        }
                        String phoneNum = Long.toString(phone);
                        reg.update(id,userName, lastName, phoneNum, userStatus); // update statement for sql server
                        refreshTable(); //auto updates the table after any query is passed in sql server
                        JOptionPane.showMessageDialog(self,"Data of " +userName+" has been updated successfully","Success",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                catch (NumberFormatException Ex) {
                    JOptionPane.showMessageDialog(self,"Enter the number in Phone text area","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    } //updates JTable records

    public static void main(String[] args){
        new Frontend();
    }
}
