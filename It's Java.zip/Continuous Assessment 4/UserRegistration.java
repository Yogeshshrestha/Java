import Helpers.DBUtils;

import java.sql.*;

public class UserRegistration {
    private Connection con;
    //for connection with sql server
    public UserRegistration(){
        try {
            con = DBUtils.getDbConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //insert statement for database
    void insert(String firstName, String lastName, String phoneNumber, String status){
        try {
            String insert = "INSERT INTO users (first_name, last_name, phone, status)" +
                    "VALUES (?,?,?,?)"; // insert statement used by sql server ? refers to the values to be inserted
            PreparedStatement statement = con.prepareStatement((insert)); //prepares insert statement
            statement.setString(1,firstName);
            statement.setString(2,lastName);
            statement.setString(3,phoneNumber);
            statement.setString(4,status);

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //select statement for database
    ResultSet get(){
        try {
            String select = "SELECT * FROM users"; //select statement used by sql server
            PreparedStatement statement = con.prepareStatement(select); //prepares select statement
            return statement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //update statement for database
    void update(String id, String firstName, String lastName,String phoneNumber, String status){
        try {
            String update = "UPDATE users SET first_name = ?, last_name=?, phone=?, status=? WHERE phone=?"; // update statement used by sql server using phone column ? refers to values to be updated
            PreparedStatement statement = con.prepareStatement(update); //prepares update query
            statement.setString(1,firstName);
            statement.setString(2,lastName);
            statement.setString(3,phoneNumber);
            statement.setString(4,status);
            statement.setString(5,id);

            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //delete statement for database//
    void delete(String phone){
        try {
            String delete = "DELETE FROM users WHERE phone= ?"; //delete statement used by sql server where ? refers value
            PreparedStatement statement = con.prepareStatement(delete); //prepares delete query
            statement.setString(1,phone); //deletes record from sql server using phone column
            statement.execute();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
