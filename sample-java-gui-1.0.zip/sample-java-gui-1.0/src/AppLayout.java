import javax.swing.*;

public interface AppLayout {
    JPanel panelUI();
}
