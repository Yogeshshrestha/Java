package Coursework;
import java.util.ArrayList;
import java.util.Collections;
import java.lang.IndexOutOfBoundsException;

public class GameParlour
{
    private ArrayList <VideoGameStation> gameList = new ArrayList<VideoGameStation>();

    public void addStation(String gameStation, String videoGame, int hourlyRate){
        this.gameList.add(new VideoGameStation(gameStation,videoGame,hourlyRate));
    }

    public void removeStation(int index){
        try{
            this.gameList.remove(index);
        }
        catch(IndexOutOfBoundsException ex){
            System.out.println("Game doesnot exist");
        }
    } 

    public void bookStation(int index,String customerName, String customerType, String bookingDate, int duration){
        try{
            VideoGameStation v = this.gameList.get(index);
            v.book(customerName,customerType,bookingDate,duration);
        }
        catch(IndexOutOfBoundsException ex){
            System.out.println("The game isnot available");
        }
    }

    public void gameFree(int index){
        try{
            VideoGameStation v = this.gameList.get(index);
            v.isAvailable();
        }
        catch(IndexOutOfBoundsException ex){
            System.out.println("Game with this index doesnot exist");
        }
    }

    public void gameDisplay(){
        for(VideoGameStation z: gameList){
            if(z.getStatus()){
                System.out.println("Gamestation detail No:" + gameList.indexOf(z));
                z.display();
            }
        }
    }

    public void search(String gameName,int hourlyRate){
        for(VideoGameStation z: gameList){
            if(z.getStatus()){
                if(z.getGameStation().equalsIgnoreCase(gameName) && z.getRate()<= hourlyRate)
                {
                    System.out.println("Game Station detail No:" + gameList.indexOf(z));
                    z.display();
                }
            }
            else{
                System.out.println("Game Station doesnot exist");
            }
        }
    }

    public void displayAscending(){
        Collections.sort(gameList);
        
        for(VideoGameStation z: gameList){
            if(!z.getStatus()){
                System.out.println("Video Game Station Name:" + z.getGameStation());
                System.out.println("Customer Name:" + z.getCustomerName());
            }
        }
    }
}
