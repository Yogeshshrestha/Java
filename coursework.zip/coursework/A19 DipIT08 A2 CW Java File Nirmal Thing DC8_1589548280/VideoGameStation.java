package Coursework;

public class VideoGameStation implements Comparable<VideoGameStation>
{
    private String gameStation;
    private String videoGame;
    private String customerName;
    private String customerType;
    private String bookingDate;
    private int duration;
    private int hourlyRate;
    private boolean availableStatus;

    public VideoGameStation(String gameStation, String videoGame, int hourlyRate){
        this.gameStation = gameStation;
        this.videoGame = videoGame;
        this.hourlyRate = hourlyRate;
        this.customerName = "";
        this.customerType = "";
        this.bookingDate = "";
        this.duration = 0;
        this.availableStatus = true;
    }

    public String getGameStation(){
        return gameStation;
    }

    public String getVideoGame(){
        return videoGame;
    }

    public String getCustomerName(){
        return customerName;
    }

    public String getCustomerType(){
        return customerType;
    }

    public String getBooking(){
        return bookingDate;
    }

    public int getDuration(){
        return duration;
    }

    public int getRate(){
        return hourlyRate;
    }

    public boolean getStatus(){
        return availableStatus;
    }

    public void setCustomType(String customerType){
        this.customerType = customerType;
    }

    public void setHour(int hour){
        this.hourlyRate = hour;
    }

    public void book(String customerName, String customerType, String bookingDate, int duration){
        if(this.availableStatus == false){
            System.out.println("Video game isnot available");
        }
        else{
        this.customerName = customerName;
        this.customerType = customerType;
        this.bookingDate = bookingDate;
        this.duration = duration;
        this.availableStatus = false;
        System.out.println("Dear " + customerName + " your booking has been recorded.");
    }
    }

    public void isAvailable(){
        if(this.availableStatus == true)
        {
            System.out.println("The gamestation is open,dear customers you can book it.");
        }
        else{
            this.customerName = "";
            this.customerType = "";
            this.bookingDate = "";
            this.duration = 0;
            this.availableStatus = true;
        }
    }

    public void display(){
        System.out.println("Game station: " + getGameStation());
        System.out.println("Hourly Rate: " + getRate());
    }

    public int compareTo(VideoGameStation obj){
        return customerName.compareTo(obj.customerName);
    }
}
