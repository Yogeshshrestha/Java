
public class VideoGameStation
{
    private String gameStation;
    private String videoGame;
    private String customerName;
    private String customerType;
    private String bookingDate; 
    private int duration;
    private float hourlyRate;
    
    public VideoGameStation(String gameStation, String videoGame, int hourlyRate){
        this.gameStation = "PS4";
        this.videoGame = "Naruto Ultimate Ninja Impact 4";
        this.customerName = "";
        this.customerType = "";
        this.bookingDate = "";
        this.duration = 0;
        this.hourlyRate = 50;
    }
   
    public void VideoGameStation(String gameStation, String videoGame, int hourlyRate){
        System.out.println("gameStation:" + this.gameStation);
        System.out.println("videoGame:" + this.videoGame);
        System.out.println("customerName:" + this.customerName);
        System.out.println("customerType:" + this.customerType);
        System.out.println("bookingDate:" + this.bookingDate);
        System.out.println("duration:" + this.duration);
        System.out.println("hourlyRate:" + this.hourlyRate);
    }
    
    public static void main (String[] args){
    
    int availableStatus = 0;
    
    if (availableStatus == 0) {
        System.out.println("This time is available to book");
    }
    
    else {
         System.out.println("This time is not available to book");
    }
}
}

